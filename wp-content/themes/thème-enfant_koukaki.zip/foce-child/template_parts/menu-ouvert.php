<img class="menu_ouvert_logo" src="<?php echo get_theme_file_uri() . '/assets/images/image_logo_en_paralax.png'; ?>" alt="">
<ul class="menu_ouvert_contenu">
    <li class="menu_ouvert_histoire"><a href="#histoire">Histoire</a></li>
    <li class="menu_ouvert_personnages"><a href="#personnages">Personnages</a></li>
    <li class="menu_ouvert_lieu"><a href="#lieu">Lieu</a></li>
    <li class="menu_ouvert_studio"><a href="#studio">Studio Koukaki</a>
    </li>
</ul>
<div class="menu_ouvert_footer">
    <a href="#">STUDIO KOUKAKI</a></li>
</div>